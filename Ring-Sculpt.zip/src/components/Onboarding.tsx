
import React, { useEffect } from 'react';
import { driver } from 'driver.js';
import 'driver.js/dist/driver.css';

interface OnboardingProps {
  runOnMount?: boolean;
}

export const Onboarding: React.FC<OnboardingProps> = ({ runOnMount = false }) => {
  const startTour = () => {
    const driverObj = driver({
      showProgress: true,
      animate: true,
      doneBtnText: 'Готово',
      nextBtnText: 'Далее →',
      prevBtnText: '← Назад',
      progressText: 'Шаг {{current}} из {{total}}',
      steps: [
        {
          element: '#canvas-container',
          popover: {
            title: '🎨 3D Холст',
            description: 'Здесь отображается ваша 3D-модель. Зажмите ЛКМ для вращения, ПКМ для сдвига и колесико мыши для зума.',
            side: 'bottom',
            align: 'start'
          }
        },
        {
          element: '#sculpt-tools',
          popover: {
            title: '🛠 Инструменты скульптинга',
            description: 'Выбирайте режимы лепки (наращивание, вдавливание, сглаживание) для изменения формы объекта.',
            side: 'right',
            align: 'center'
          }
        },
        {
          element: '#brush-settings',
          popover: {
            title: '🪶 Настройка кисти',
            description: 'Регулируйте размер кисти, силу воздействия и цвет материала.',
            side: 'left',
            align: 'center'
          }
        },
        {
          element: '#cart-drawer-toggle',
          popover: {
            title: '🛒 Экспорт и Заказ',
            description: 'Сохраняйте результат, экспортируйте 3D-модель или оформляйте заказ готового изделия.',
            side: 'bottom',
            align: 'end'
          }
        }
      ]
    });

    driverObj.drive();
  };

  useEffect(() => {
    // Запускаем автоматически при первом посещении
    const hasSeenTour = localStorage.getItem('has_seen_onboarding');
    if (!hasSeenTour || runOnMount) {
      startTour();
      localStorage.setItem('has_seen_onboarding', 'true');
    }
  }, [runOnMount]);

  return (
    <button
      onClick={startTour}
      className="fixed bottom-4 right-4 z-50 flex items-center gap-2 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-full shadow-lg transition-all"
      title="Пройти обучение"
    >
      <span className="text-base">❓</span> Обучение
    </button>
  );
};